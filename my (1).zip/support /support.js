document.getElementById('send-btn').addEventListener('click', function() {
    const input = document.getElementById('chat-input');
    const message = input.value;

    if (message.trim() !== '') {
        const chatArea = document.getElementById('chat-area');
        const messageDiv = document.createElement('div');
        messageDiv.classList.add('chat-message');
        messageDiv.textContent = `You: ${message}`;
        chatArea.appendChild(messageDiv);

        input.value = '';
        chatArea.scrollTop = chatArea.scrollHeight; // Scroll to bottom
    }
});